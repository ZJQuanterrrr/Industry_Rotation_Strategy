# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from decimal import Decimal, ROUND_HALF_UP
import math


# -----读取步骤二整理的数据，并再次进行初步整理-----
Dataframe_d_return_1 = pd.read_csv('.\Data_after_first_cleaning\Dataframe_1.csv')
Dataframe_d_mar_cap_2 = pd.read_csv('.\Data_after_first_cleaning\Dataframe_2.csv')
Dataframe_d_PB_3 = pd.read_csv('.\Data_after_first_cleaning\Dataframe_3.csv')

# 发布日期这一列的向量将作为后续Dataframe的行名，先存下
date = Dataframe_d_return_1["发布日期"]

# 将发布日期作为各表的index
Dataframe_d_return_1.set_index("发布日期", inplace = True)
Dataframe_d_mar_cap_2.set_index("发布日期", inplace = True)
Dataframe_d_PB_3.set_index("发布日期", inplace = True)

# 表头的名称向量将作为后续Dataframe的列名，先存下
name = list(Dataframe_d_return_1)

# 计算资产的数量，即行指的个数（获取Dataframe的列数）
n_assets = Dataframe_d_return_1.shape[1]

# 计算各交易日各行指：（市值/行业总市值）**（1/2）的值
Dataframe_d_mar_cap_2['Row_sum'] = Dataframe_d_mar_cap_2.apply(lambda x: x.sum(), axis=1)
for nm in name:
    
    Dataframe_d_mar_cap_2[nm] = Dataframe_d_mar_cap_2[nm]/Dataframe_d_mar_cap_2["Row_sum"]
    Dataframe_d_mar_cap_2[nm] = Dataframe_d_mar_cap_2[nm]**(1/2)

df_relative_mc = Dataframe_d_mar_cap_2.drop(columns = "Row_sum")

# 将收益率数据乘以各行业各行指的（市值/行业总市值）**（1/2）形成市值相对收益率
df_relative_return = Dataframe_d_return_1 * df_relative_mc





# -----计算各行业各交易日的行业集中度（Centrality）并形成一张csv表-----
# 由于计算需要交易日前两年的历史收益率数据，假定一年交易日 d = 250 天，从2014-02-21往后第500个交易日（算上2014-02-21）开始计算其相应风险集中度（Absorption ratio）
# 继而计算各行业相应的资产集中度（Centrality）

# 存储各交易日各行业的Absorption ratio
Absp_r=[]

window = 500 #滚动窗口期，两年
days = len(df_relative_return) #数据总共的交易天数
fraction_eigenvectors = 0.2 #学术界一般设定的值

print("Computing Centrality process:")

# 开始滚动
for n in range(days - window + 1):
    
    absp_r = []
    
    # 设定计算协方差矩阵的窗口
    df_r = df_relative_return.iloc[n: n + window, : ]
    
    # 计算协方差矩阵
    df_cov = df_r.cov()
    
    value, vector = np.linalg.eig(df_cov) #计算协方差矩阵的特征值和特征向量
    
    # 计算最大的5个特征值对应的特征向量的Absorption ratio
    eig = np.linalg.eigvals(df_cov)
    eig_sorted = sorted(eig)
    num_eigenvalues = int(Decimal(fraction_eigenvectors * n_assets).to_integral_value(rounding=ROUND_HALF_UP))
    Ar_list = eig_sorted[len(eig_sorted) - num_eigenvalues: ] / np.trace(df_cov) #计算最大的几个特征向量（本文中是5个）的Absorption ratio
    Ar = sum(eig_sorted[len(eig_sorted) - num_eigenvalues: ]) / np.trace(df_cov) #计算5个特征向量加总的Absorption ratio
    
    # 将前五个特征向量取出并各元素取绝对值
    EV = vector[:5]
    EV_abs = np.maximum(EV, -EV)
    
    # 计算各个特征向量的EV
    EVs = np.sum(EV_abs, axis=1)
    
    # 开始计算Centrality
    for i in range(n_assets):
        
        Numerator = 0 #计算Centrality时的分子
        
        std_variance = float(np.std(df_r.iloc[:, i: i+1]))
        
        EV_sum = 0
        for j in range(num_eigenvalues):
            
            EV_sum = EV_sum + math.sqrt(value[j]) * EV_abs[j][i]/std_variance
        
        for j in range(num_eigenvalues):
            
            Numerator = Numerator + Ar_list[j] * ((math.sqrt(value[j]) * EV_abs[j][i]/std_variance)/EV_sum)
            
        Centrality_i = Numerator/Ar
        
        absp_r.append(Centrality_i) #收集该交易日的各行业Centrality
        
    Absp_r.append(absp_r) #将形成的array储存
    
    print(n, "is finished")
    
date_Ar = date[window - 1: ]

#形成该表
df_Ar = pd.DataFrame(Absp_r)
df_Ar.set_index(date_Ar, inplace=True)
df_Ar.columns = name

#生成csv文件输出
df_Ar.to_csv('.\Data_after_second_cleaning\Centrality.csv', encoding='utf_8_sig')





#-----由于不同行业Centrality可能天然存在差异，故以两年为窗口期再次滚动，计算Centrality的z-score数据作为新的Centrality-----
# 存储算得的Centrality_adj
Cen_adj = []

window = 500 #窗口期，同样为两年
days = len(df_Ar)
new_date = list(df_Ar.index)

# 开始滚动
for n in range(days - window):
    
    df_cen_z = df_Ar.iloc[n: n + window, : ] #设定窗口   
    
    cen_adj = []
    
    for j in range(len(name)):
        
        ave = float(np.sum(df_cen_z[name[j]])/len(df_cen_z)) #计算交易日前两年的Centrality均值
        
        std = float(np.std(df_cen_z[name[j]])) #计算交易日前两年的Centrality标准差
        
        value = df_Ar.iloc[500, j]
        
        cen = (value - ave)/std #交易日的adjusted Centrality
        
        cen_adj.append(cen)
     
    Cen_adj.append(cen_adj)
    
date_cen = new_date[window: ]

#形成该表
df_adj_cen = pd.DataFrame(Cen_adj)
df_adj_cen.index = date_cen
df_adj_cen.columns = name

#生成csv文件输出
df_adj_cen.to_csv('.\Data_after_second_cleaning\Centrality.csv', encoding='utf_8_sig')





#-----计算各行业各交易日的相对价值指标（Relative PB）并形成一张csv表-----
# 该计算同样需要交易日前两年的历史PB数据，假定一年交易日 d = 250 天，从2014-02-21往后第500个交易日（算上2014-02-21）开始计算其Relative PB

# 存储交易日各行业的Relative PB
R_PB = []

window = 500 #滚动窗口期，两年
days = len(Dataframe_d_PB_3) #数据总共的交易天数

# 开始滚动
# for n in range(0, 1):
for n in range(days - window + 1):
    
    r_PB = []
    
    # 设定计算相对PB的窗口
    df_pb = Dataframe_d_PB_3.iloc[n: n + window, : ]
    # df_pb.loc['2_year_Average'] = df_pb.apply(lambda x: x.sum())/window
    pb_d_list = list(df_pb.iloc[window-1])
    # pb_d_average = list(df_pb.iloc[window])
    
    # 计算各个行指该日的Relative PB
    for i in range(n_assets):
        
        # pb_other_sum = 0
        
        # for j in range(n_assets):
            
        #     if j != i:
                
        #         pb_other_sum = pb_other_sum + float(np.sum(df_pb[df_pb.columns[j]])/window)
                
        # pb_other_average = pb_other_sum/(n_assets - 1)
        # r_pb = pb_d_list[i]/ (np.sum(df_pb[df_pb.columns[i]])/window) /pb_other_average
        r_pb = pb_d_list[i]/ (np.sum(df_pb[df_pb.columns[i]])/window)/ float(np.std(df_pb[df_pb.columns[i]]))
        
        # 存储
        r_PB.append(r_pb)
        
    # 存储
    R_PB.append(r_PB)
    
date_PB = date[window-1: ]

#形成该表
df_PB = pd.DataFrame(R_PB)
df_PB.set_index(date_PB, inplace=True)
df_PB.columns = name

df_PB = df_PB.iloc[window: , :]

#生成csv文件输出
df_PB.to_csv('.\Data_after_second_cleaning\Relative_PB.csv', encoding='utf_8_sig')